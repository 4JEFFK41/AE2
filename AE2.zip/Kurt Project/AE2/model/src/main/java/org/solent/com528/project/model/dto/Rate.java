package org.solent.com528.project.model.dto;

public enum Rate {

    PEAK, OFFPEAK
}
