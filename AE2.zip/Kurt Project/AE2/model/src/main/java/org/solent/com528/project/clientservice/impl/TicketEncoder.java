package org.solent.com528.project.clientservice.impl;

import org.solent.com528.project.model.dto.Ticket;

public abstract class TicketEncoder {

    public static String encodeTicket(Ticket ticket) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public static boolean validateTicket(String encodedTicket) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
