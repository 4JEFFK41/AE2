
# Java Web WAR

To run Tomcat as an embedded service using Tomcat

```
mvn org.codehaus.cargo:cargo-maven2-plugin:run
```

then navigate to http://localhost:8080/basicfacadeweb/






