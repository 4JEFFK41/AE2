# Report

## Decisions on Diagrams

### Domain Diagram

I created my diagram in two sections with one aimed towards the standard user side of the program and the ReST user side of the program in two different instances. This splits the information up and gives a good demonstration of how an admin and client would use the program efficiently. For the customer part of the diagram I focused mostly on the ticket object creation process which then enables the respective DAO handle calculations. The ReST side was similar in design with the CRUD operations being dealt with by the DAO and the addition of modifying a station going to a Station.jsp which would allow you to assign and create TicketMachines to the respective station.

After much trial and error I feel the final product was overall a good attempt from the criteria with minor code changes.

### Use-Case

The use cases are all seperated into different instances and clearly shows how each instance is performed. The reason behind this is because it allows me to show the functionality of each part based on the specific roles of characters. An example would be that the customer shows actions that are needed to both make use of the ticket machine/ticket gate specifically the input of data. The ReST user is responsible for everything that consists of creating Stations and their respected tickets which will directly affect the user.


## Test plan

I used my usecases as a building point for my test plan focusing on tests that influence the jsp's created. I made both successful and unsuccesful tests which show the accuracy of the 
program. The tests are mainly focused in the Customer section, with the main of the tests focused on inputting data and showing whether or not an error occurred.

