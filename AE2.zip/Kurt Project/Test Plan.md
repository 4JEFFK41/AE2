# Test Plan

|#| Name|Purpose|Expected|Actual|
|---|---|---|---|---|
|1|getCurrentStationName|To get current station name from the ticket machine config from uuid|It will get the correct station name and display it|Displays null - Fail|

|2|getCurrentStationZone|Get the station zone from the uuid|Displays the corresponding station Zone|Displays correct station zone - Pass|

|3|listDestinationZones|Create list of destination zone buttons|Creates a list of buttons|Dreates a list of destination zone buttons - Pass|

|4|stationListDropbox|Create a dropdown with all stations|Creates a dropbox that lists stations|Creates the dropdown that lists stations - Pass|

|5|creditCardCheckTrue|Compare and the input on the credit field for validity|Return true from a correct value |Returns True - Pass|

|6|calculatePriceZones|Minus destination zone from starting zone|Produce a positive value to be used for calculation|Positive value - Pass|

|7|generateTicket|Produces a valid ticket to be used for ticketGate.jsp|Produces a ticket with all fields filled|Produces a valid ticket - Pass|

|8|decodeTicket|Get the ticket XML data from user|decode the ticket data|decodes XML - Pass|

|9|validateDate|compare arrival time and issue time|Valid within 24 hours|Time is valid - Pass|

|10|openGateError|If validStation, validDate and validFormat are false see if gate opens|Gate will remain closed|Gate opens - Fail|

